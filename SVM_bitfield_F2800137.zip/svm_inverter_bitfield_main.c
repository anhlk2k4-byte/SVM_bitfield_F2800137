//#############################################################################
// Three-phase inverter - Space Vector Modulation PWM
// Device: LaunchXL-F2800137
//
// Target:
// - PWM frequency: 20 kHz
// - Dead-band: 300 ns
// - ePWM1A/B -> GPIO0/GPIO1 -> phase A high/low
// - ePWM2A/B -> GPIO2/GPIO3 -> phase B high/low
// - ePWM3A/B -> GPIO4/GPIO5 -> phase C high/low
//
// Revision notes (clean / fixed):
// 1) PWM_TBPRD and DEADTIME_300NS_COUNT are now DERIVED from SYSCLK_FREQ_HZ
//    instead of being hard-coded "magic numbers". The original file assumed
//    SYSCLKOUT = TBCLK = 120 MHz. TI's datasheet rates the F2800137 C28x
//    core at up to 120 MHz, but TI's own LaunchPad user guide (SPRUJ32)
//    states the factory/example configuration runs the device at 100 MHz.
//    Because this file does not include the InitSysCtrl()/PLL setup, the
//    real SYSCLKOUT value depends on YOUR project. Hard-coding TBPRD=3000
//    and DBRED/DBFED=36 is only correct at exactly 120 MHz; at 100 MHz it
//    silently produces 16.67 kHz / 360 ns instead of 20 kHz / 300 ns.
//    => Set SYSCLK_FREQ_HZ below to match your actual InitSysCtrl() PLL
//       configuration. Everything else is computed automatically.
// 2) Trip-Zone hardware protection has been REMOVED in this version, per
//    request. There is NO hardware over-current/short-circuit shutdown
//    in this file. Do not run this on a real power stage without adding
//    equivalent protection (Trip-Zone, external comparator/gate-driver
//    fault latch, or a fuse) suited to your hardware.
//#############################################################################

#include "f28x_project.h"
#include <math.h>
#include <stdint.h>

//
// ----------------------------------------------------------------------
// Clock / PWM timing configuration
// ----------------------------------------------------------------------
// >>> VERIFY THIS AGAINST YOUR ACTUAL InitSysCtrl() / PLL SETTINGS <<<
// SYSCLKOUT = TBCLK here because TBCTL.HSPCLKDIV = TBCTL.CLKDIV = /1
// (see configure_epwm_module()).
//
#define SYSCLK_FREQ_HZ          120000000UL  // <-- set to your real SYSCLKOUT

#define PWM_SWITCHING_FREQ_HZ   20000UL
#define PWM_TBPRD               ((uint16_t)(SYSCLK_FREQ_HZ / \
                                  (2UL * PWM_SWITCHING_FREQ_HZ)))

#define PWM_ISR_PERIOD_SEC      (1.0 / (double)PWM_SWITCHING_FREQ_HZ)

#define DEADTIME_NS              300UL
#define DEADTIME_300NS_COUNT    ((uint16_t)((DEADTIME_NS * \
                                  (SYSCLK_FREQ_HZ / 1000000UL)) / 1000UL))

#define TWO_PI                 6.283185307179586
#define TWO_PI_OVER_THREE      2.094395102393195
#define FOUR_PI_OVER_THREE     4.188790204786391
#define SQRT3                  1.732050807568877

volatile double freq = 50.0;        // Fundamental frequency
volatile double phase_angle = 0.0;

volatile double vra, vrb, vrc;
volatile double vpeak = 8.0;        // AC reference peak
volatile double vdc_bus = 24.0;
volatile double vr_alpha, vr_beta;
volatile double t_vectorx, t_vectory, t_vector0;
volatile int sector = 1;

static const double conv_vectors[8][2] = {
    { 0.0,     0.0    },
    { 0.6666,  0.0    },
    {-0.3333,  0.5773 },
    {-0.3333, -0.5773 },
    {-0.6666,  0.0    },
    { 0.3333, -0.5773 },
    { 0.3333,  0.5773 },
    { 0.0,     0.0    }
};

static const int sector_vectors[6][2] = {
    {1, 6},
    {2, 6},
    {2, 4},
    {3, 4},
    {3, 5},
    {1, 5}
};

//
// phase_sequence orders the three phase switching instants for each sector.
// 0 = phase A, 1 = phase B, 2 = phase C.
//
static const int phase_sequence[6][3] = {
    {0, 1, 2},
    {1, 0, 2},
    {1, 2, 0},
    {2, 1, 0},
    {2, 0, 1},
    {0, 2, 1}
};

static void configure_gpio_epwm_pins(void);
static void configure_epwm_module(volatile struct EPWM_REGS *epwm);
static uint16_t time_to_cmp(double switching_time);
static void set_phase_cmp(int phase, uint16_t cmp);

static uint16_t time_to_cmp(double switching_time)
{
    double cmp;

    cmp = ((double)PWM_TBPRD * switching_time) / (PWM_ISR_PERIOD_SEC / 2.0);

    if(cmp < 1.0)
    {
        cmp = 1.0;
    }
    else if(cmp > ((double)PWM_TBPRD - 1.0))
    {
        cmp = (double)PWM_TBPRD - 1.0;
    }

    return((uint16_t)cmp);
}

static void set_phase_cmp(int phase, uint16_t cmp)
{
    if(phase == 0)
    {
        EPwm1Regs.CMPA.bit.CMPA = cmp;
    }
    else if(phase == 1)
    {
        EPwm2Regs.CMPA.bit.CMPA = cmp;
    }
    else
    {
        EPwm3Regs.CMPA.bit.CMPA = cmp;
    }
}

static void configure_gpio_epwm_pins(void)
{
    EALLOW;

    //
    // Keep the pins low as GPIO outputs before switching them to ePWM.
    // This avoids a startup glitch on the gate-driver inputs.
    //
    GpioDataRegs.GPACLEAR.bit.GPIO0 = 1;
    GpioDataRegs.GPACLEAR.bit.GPIO1 = 1;
    GpioDataRegs.GPACLEAR.bit.GPIO2 = 1;
    GpioDataRegs.GPACLEAR.bit.GPIO3 = 1;
    GpioDataRegs.GPACLEAR.bit.GPIO4 = 1;
    GpioDataRegs.GPACLEAR.bit.GPIO5 = 1;

    GpioCtrlRegs.GPADIR.bit.GPIO0 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO1 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO2 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO3 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO4 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO5 = 1;

    GpioCtrlRegs.GPAPUD.bit.GPIO0 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO1 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO2 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO3 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO4 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO5 = 1;

    //
    // GPIO0/1 = ePWM1A/B, GPIO2/3 = ePWM2A/B, GPIO4/5 = ePWM3A/B.
    // F2800137 pin mux: GMUX = 0, MUX = 1.
    //
    GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO1 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;

    GpioCtrlRegs.GPAGMUX1.bit.GPIO2 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 1;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO3 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 1;

    GpioCtrlRegs.GPAGMUX1.bit.GPIO4 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 1;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO5 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 1;

    EDIS;
}

static void configure_epwm_module(volatile struct EPWM_REGS *epwm)
{
    epwm->TBCTL.bit.CTRMODE = 3;        // Stop counter during configuration
    epwm->TBCTL.bit.PHSEN = 0;
    epwm->TBCTL.bit.HSPCLKDIV = 0;      // /1
    epwm->TBCTL.bit.CLKDIV = 0;         // /1
    epwm->TBCTL.bit.FREE_SOFT = 2;      // Free run during debug halt

    epwm->TBCTR = 0;
    epwm->TBPHS.bit.TBPHS = 0;
    epwm->TBPRD = PWM_TBPRD;

    //
    // CMPA uses shadow mode and loads at CTR = ZERO.
    //
    epwm->CMPCTL.bit.SHDWAMODE = 0;
    epwm->CMPCTL.bit.LOADAMODE = 0;
    epwm->CMPA.bit.CMPA = PWM_TBPRD / 2U;

    //
    // Center-aligned pulse:
    // - set ePWMxA when counting up reaches CMPA
    // - clear ePWMxA when counting down reaches CMPA
    //
    epwm->AQCTLA.all = 0;
    epwm->AQCTLA.bit.CAU = 2;
    epwm->AQCTLA.bit.CAD = 1;

    //
    // ePWMxB is generated by the dead-band module, so AQB is not used.
    //
    epwm->AQCTLB.all = 0;

    //
    // Classic active-high complementary dead-band.
    // IN_MODE = 0: RED and FED both use ePWMxA as input.
    // POLSEL  = 2: ePWMxB is inverted.
    //
    epwm->DBCTL.bit.IN_MODE = 0;
    epwm->DBCTL.bit.POLSEL = 2;
    epwm->DBCTL.bit.OUT_MODE = 3;
    epwm->DBRED.bit.DBRED = DEADTIME_300NS_COUNT;
    epwm->DBFED.bit.DBFED = DEADTIME_300NS_COUNT;
}

__interrupt void epwm1_isr(void)
{
    double time_den;
    double tx;
    double ty;
    double t0;
    double scale;
    double t1;
    double t2;
    double t3;

    phase_angle += TWO_PI * freq * PWM_ISR_PERIOD_SEC;
    if(phase_angle >= TWO_PI)
    {
        phase_angle -= TWO_PI;
    }

    vra = vpeak * cos(phase_angle);
    vrb = vpeak * cos(phase_angle - TWO_PI_OVER_THREE);
    vrc = vpeak * cos(phase_angle - FOUR_PI_OVER_THREE);

    //
    // Clarke transform: three-phase reference -> alpha-beta vector.
    //
    vr_alpha = (2.0 / 3.0) * (vra - (0.5 * vrb) - (0.5 * vrc));
    vr_beta = (1.0 / 1.732050807568877) * (vrb - vrc);

    //
    // Determine sector in alpha-beta plane.
    //
    if(vr_alpha > 0.0)
    {
        if(vr_beta > 0.0)
        {
            sector = (vr_beta < (SQRT3 * vr_alpha)) ? 1 : 2;
        }
        else
        {
            sector = (vr_beta > (-SQRT3 * vr_alpha)) ? 6 : 5;
        }
    }
    else
    {
        if(vr_beta > 0.0)
        {
            sector = (vr_beta < (-SQRT3 * vr_alpha)) ? 3 : 2;
        }
        else
        {
            sector = (vr_beta > (SQRT3 * vr_alpha)) ? 4 : 5;
        }
    }

    time_den = vdc_bus *
               ((conv_vectors[sector_vectors[sector - 1][0]][0] *
                 conv_vectors[sector_vectors[sector - 1][1]][1]) -
                (conv_vectors[sector_vectors[sector - 1][0]][1] *
                 conv_vectors[sector_vectors[sector - 1][1]][0]));

    tx = PWM_ISR_PERIOD_SEC *
         ((vr_alpha * conv_vectors[sector_vectors[sector - 1][1]][1]) -
          (vr_beta * conv_vectors[sector_vectors[sector - 1][1]][0])) /
         time_den;

    ty = PWM_ISR_PERIOD_SEC *
         ((vr_beta * conv_vectors[sector_vectors[sector - 1][0]][0]) -
          (vr_alpha * conv_vectors[sector_vectors[sector - 1][0]][1])) /
         time_den;

    if(tx < 0.0)
    {
        tx = 0.0;
    }
    if(ty < 0.0)
    {
        ty = 0.0;
    }

    //
    // Clamp overmodulation. This prevents negative zero-vector time and keeps
    // CMPA inside the valid ePWM range.
    //
    if((tx + ty) > PWM_ISR_PERIOD_SEC)
    {
        scale = PWM_ISR_PERIOD_SEC / (tx + ty);
        tx *= scale;
        ty *= scale;
        t0 = 0.0;
    }
    else
    {
        t0 = PWM_ISR_PERIOD_SEC - (tx + ty);
    }

    t_vectorx = tx;
    t_vectory = ty;
    t_vector0 = t0;

    //
    // Symmetrical SVPWM sequence:
    // V0 - Vx - Vy - V7 - V7 - Vy - Vx - V0.
    //
    t1 = t0 / 4.0;
    t2 = t1 + (tx / 2.0);
    t3 = t2 + (ty / 2.0);

    set_phase_cmp(phase_sequence[sector - 1][0], time_to_cmp(t1));
    set_phase_cmp(phase_sequence[sector - 1][1], time_to_cmp(t2));
    set_phase_cmp(phase_sequence[sector - 1][2], time_to_cmp(t3));

    //
    // Clear peripheral interrupt flag first, then acknowledge PIE group 3.
    //
    EPwm1Regs.ETCLR.bit.INT = 1;
    PieCtrlRegs.PIEACK.bit.ACK3 = 1;
}

void main(void)
{
    InitSysCtrl();

    InitPieCtrl();
    IER = 0x0000;
    IFR = 0x0000;
    InitPieVectTable();

    EALLOW;
    CpuSysRegs.PCLKCR2.bit.EPWM1 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM2 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM3 = 1;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;
    EDIS;

    configure_epwm_module(&EPwm1Regs);
    configure_epwm_module(&EPwm2Regs);
    configure_epwm_module(&EPwm3Regs);

    //
    // ePWM1 provides the single ISR tick for all three phases.
    //
    EPwm1Regs.ETSEL.bit.INTSEL = 1;     // Interrupt at CTR = ZERO
    EPwm1Regs.ETSEL.bit.INTEN = 1;
    EPwm1Regs.ETPS.bit.INTPRD = 1;
    EPwm1Regs.ETCLR.bit.INT = 1;

    EPwm2Regs.ETSEL.bit.INTEN = 0;
    EPwm3Regs.ETSEL.bit.INTEN = 0;

    EALLOW;
    PieVectTable.EPWM1_INT = &epwm1_isr;
    EDIS;

    PieCtrlRegs.PIEIER3.bit.INTx1 = 1;
    IER |= M_INT3;

    configure_gpio_epwm_pins();

    EPwm1Regs.TBCTL.bit.CTRMODE = 2;    // Up-down count
    EPwm2Regs.TBCTL.bit.CTRMODE = 2;
    EPwm3Regs.TBCTL.bit.CTRMODE = 2;

    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;

    EINT;
    ERTM;

    while(1)
    {
    }
}

//
// End of File
//
