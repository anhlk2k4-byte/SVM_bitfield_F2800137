################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../280013x_generic_ram_lnk.cmd \
../f280013x_headers_nonBIOS.cmd 

ASM_SRCS += \
../f280013x_codestartbranch.asm \
../f280013x_usdelay.asm 

C_SRCS += \
../f280013x_defaultisr.c \
../f280013x_globalvariabledefs.c \
../f280013x_gpio.c \
../f280013x_piectrl.c \
../f280013x_pievect.c \
../f280013x_sysctrl.c \
../svm_inverter_bitfield_main.c 

C_DEPS += \
./f280013x_defaultisr.d \
./f280013x_globalvariabledefs.d \
./f280013x_gpio.d \
./f280013x_piectrl.d \
./f280013x_pievect.d \
./f280013x_sysctrl.d \
./svm_inverter_bitfield_main.d 

OBJS += \
./f280013x_codestartbranch.obj \
./f280013x_defaultisr.obj \
./f280013x_globalvariabledefs.obj \
./f280013x_gpio.obj \
./f280013x_piectrl.obj \
./f280013x_pievect.obj \
./f280013x_sysctrl.obj \
./f280013x_usdelay.obj \
./svm_inverter_bitfield_main.obj 

ASM_DEPS += \
./f280013x_codestartbranch.d \
./f280013x_usdelay.d 

OBJS__QUOTED += \
"f280013x_codestartbranch.obj" \
"f280013x_defaultisr.obj" \
"f280013x_globalvariabledefs.obj" \
"f280013x_gpio.obj" \
"f280013x_piectrl.obj" \
"f280013x_pievect.obj" \
"f280013x_sysctrl.obj" \
"f280013x_usdelay.obj" \
"svm_inverter_bitfield_main.obj" 

C_DEPS__QUOTED += \
"f280013x_defaultisr.d" \
"f280013x_globalvariabledefs.d" \
"f280013x_gpio.d" \
"f280013x_piectrl.d" \
"f280013x_pievect.d" \
"f280013x_sysctrl.d" \
"svm_inverter_bitfield_main.d" 

ASM_DEPS__QUOTED += \
"f280013x_codestartbranch.d" \
"f280013x_usdelay.d" 

ASM_SRCS__QUOTED += \
"../f280013x_codestartbranch.asm" \
"../f280013x_usdelay.asm" 

C_SRCS__QUOTED += \
"../f280013x_defaultisr.c" \
"../f280013x_globalvariabledefs.c" \
"../f280013x_gpio.c" \
"../f280013x_piectrl.c" \
"../f280013x_pievect.c" \
"../f280013x_sysctrl.c" \
"../svm_inverter_bitfield_main.c" 


